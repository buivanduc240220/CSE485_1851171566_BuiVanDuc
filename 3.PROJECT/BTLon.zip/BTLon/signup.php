<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Registrationsss</title>
    <link rel="stylesheet" type="text/css" href="css/signin.css">
</head>
<body>
    <center>
    <div class="header">
        <h2>Register</h2>
    </div>
    </center>

    <!-- ket nôi sql -->
<?php
    $conn = mysqli_connect('localhost','root','','cuoiky');
    if(!$conn){
        die('Lỗi! Không thể kết nối');
        exit();
    }
    if(isset($_POST['register']))
    {
        $username=$_POST['username'];
        $email= $_POST['email'];
        $password=$_POST['password_1'];
    
    $sql="INSERT INTO register_signin (username, email,password) VALUES ('$username','$email','$password')";
    $query =mysqli_query($conn, $sql);
    header('Location:signin.php');
}
     
?>


  <form method="post"  >
<!-- display validation here -->
   
    <div class="input-group">   
        <label >Username</label>
        <input type="text" name="username" required>
     </div>

     <div class="input-group">   
        <label >Email</label>
        <input type="text" name="email" required>
     </div>

     <div class="input-group">   
        <label >Password</label>
        <input type="password" name="password_1" required>
    </div>

     <div class="input-group">   
        <button type="submit" name="register" class="btn">Register</button>
        <button type="submit" name="quaylai" class="btn"><a href="webkhoa.php" style="color: white; text-decoration:none;">Cancel</a> </button>
        </div>
     <p>
         Already a member ?<a href="signin.php">Sign In</a>
     </p>
 </form>

</body>
</html>

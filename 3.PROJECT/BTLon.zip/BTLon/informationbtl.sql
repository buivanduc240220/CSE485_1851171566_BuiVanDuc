-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1
-- Thời gian đã tạo: Th10 13, 2020 lúc 07:30 PM
-- Phiên bản máy phục vụ: 10.4.13-MariaDB
-- Phiên bản PHP: 7.4.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `cuoiky`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `information`
--

CREATE TABLE `information` (
  `id` int(20) NOT NULL,
  `hoten` varchar(255) NOT NULL,
  `gioitinh` varchar(255) NOT NULL,
  `ngaysinh` varchar(255) NOT NULL,
  `noisinh` varchar(255) NOT NULL,
  `dantoc` varchar(255) NOT NULL,
  `tongiao` varchar(255) NOT NULL,
  `namtotnghiep` date NOT NULL,
  `hocluc12` varchar(255) NOT NULL,
  `hanhkiem12` varchar(255) NOT NULL,
  `cmnd` int(20) NOT NULL,
  `ngaycap` date NOT NULL,
  `noicap` varchar(255) NOT NULL,
  `hokhau` varchar(255) NOT NULL,
  `matinh10` int(11) NOT NULL,
  `matinh11` int(11) NOT NULL,
  `matinh12` int(11) NOT NULL,
  `tentinh10` varchar(255) NOT NULL,
  `tentinh11` varchar(255) NOT NULL,
  `tentinh12` varchar(255) NOT NULL,
  `matruong10` int(11) NOT NULL,
  `matruong11` int(11) NOT NULL,
  `matruong12` int(11) NOT NULL,
  `tentruong10` varchar(255) NOT NULL,
  `tentruong11` varchar(255) NOT NULL,
  `tentruong12` varchar(255) NOT NULL,
  `doituongut` varchar(255) NOT NULL,
  `khuvucut` varchar(255) NOT NULL,
  `diachilh` varchar(255) NOT NULL,
  `sdths` varchar(255) NOT NULL,
  `sdtph` varchar(255) NOT NULL,
  `dtb12` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `information`
--

INSERT INTO `information` (`id`, `hoten`, `gioitinh`, `ngaysinh`, `noisinh`, `dantoc`, `tongiao`, `namtotnghiep`, `hocluc12`, `hanhkiem12`, `cmnd`, `ngaycap`, `noicap`, `hokhau`, `matinh10`, `matinh11`, `matinh12`, `tentinh10`, `tentinh11`, `tentinh12`, `matruong10`, `matruong11`, `matruong12`, `tentruong10`, `tentruong11`, `tentruong12`, `doituongut`, `khuvucut`, `diachilh`, `sdths`, `sdtph`, `dtb12`) VALUES
(4, 'Nguyễn Văn b   ', 'Nữ', '2000-02-20', 'TP HCM', 'Kinh', 'Không', '0000-00-00', 'Giỏi', 'Tốt', 262, '0000-00-00', 'Hà Nội', 'Hà Nội', 1, 1, 1, 'Hà Nội', 'Hà Nội', 'Hà Nội', 1, 1, 1, 'HN', 'HN', 'HN', 'kv1', 'kv1', 'HN', '1234', '0123', 0),
(5, 'Nguyễn Văn A', 'Nữ', '19999-02-12', 'Hà Nội', 'Kinh', 'Không', '0000-00-00', 'Giỏi', 'Tốt', 435, '0000-00-00', 'Hà Nội', 'Hà Nội', 1, 1, 1, 'Hà Nội', 'Hà Nội', 'Hà Nội', 1, 1, 1, 'HN', 'HN', 'HN', 'kv1', 'kv1', 'HN', '123', '2468', 0);

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `information`
--
ALTER TABLE `information`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `information`
--
ALTER TABLE `information`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.14.0/css/all.min.css">

<?php
    require('includes/config.php'); 
 
    $id = $_GET['id'];
    $sql_up = "SELECT * FROM information WHERE id = $id";
    $query_up = mysqli_query($conn, $sql_up);
    $row_up = mysqli_fetch_assoc($query_up);
 
    if(isset($_POST['save'])){
        $HoTen = $_POST['Hoten'];
        $GioiTinh  = $_POST['Gioitinh'];
        $NgaySinh = $_POST['Ngaysinh'];
        $NoiSinh = $_POST['Noisinh'];
        $DanToc = $_POST['Dantoc'];
        $TonGiao = $_POST['Tongiao'];
        $NamTotNghiep = $_POST['Namtotnghiep'];
        $HocLuc12 = $_POST['Hocluc12'];
        $HanhKiem12 = $_POST['Hanhkiem12'];
        $Cmnd = $_POST['cmnd'];
        $NgayCap = $_POST['Ngaycap'];
        $NoiCap = $_POST['Noicap'];
        $HoKhau = $_POST['Hokhau'];
        $MaTinh10 = $_POST['Matinh10'];
        $MaTinh11 = $_POST['Matinh11'];
        $MaTinh12 = $_POST['Matinh12'];
        $TenTinh10 = $_POST['Tentinh10'];
        $TenTinh11 = $_POST['Tentinh11'];
        $TenTinh12 = $_POST['Tentinh12'];
        $MaTruong10 = $_POST['Matruong10'];
        $MaTruong11 = $_POST['Matruong11'];
        $MaTruong12 = $_POST['Matruong12'];
        $TenTruong10 = $_POST['Tentruong10'];
        $TenTruong11 = $_POST['Tentruong11'];
        $TenTruong12 = $_POST['Tentruong12'];
        $DoiTuongUT = $_POST['DoituongUT'];
        $KhuVucUT = $_POST['KhuvucUT'];
        $DiaChiLH = $_POST['DiachiLH'];
        $Sdths = $_POST['Sdths'];
        $Sdtph = $_POST['Sdtph'];
        $Dtb12 = $_POST['Dtb12'];
 
        $sql = " UPDATE information SET hoten ='$HoTen' , gioitinh = '$GioiTinh', ngaysinh = '$NgaySinh' ,   noisinh = '$NoiSinh' , dantoc = '$DanToc'   ,tongiao = '$TonGiao' , namtotnghiep = '$NamTotNghiep' , hocluc12 = '$HocLuc12' , hanhkiem12 = '$HanhKiem12' , cmnd = '$Cmnd', ngaycap= '$NgayCap' , noicap = '$NoiCap' , hokhau = '$HoKhau' ,matinh10= '$MaTinh10' , matinh11= '$MaTinh11' , matinh12= '$MaTinh12' , tentinh10= '$TenTinh10', tentinh11= '$TenTinh11' , tentinh12= '$TenTinh12' , matruong10= '$MaTruong10'  , matruong11= '$MaTruong11' , matruong12='$MaTruong12' , tentruong10= '$TenTruong10' , tentruong11='$TenTruong11' , tentruong12='$TenTruong12' , doituongut='$DoiTuongUT' , khuvucut='$KhuVucUT' , diachilh='$DiaChiLH' , sdths='$Sdths' , sdtph='$Sdtph' , dtb12='$Dtb12' WHERE id = $id ";
 
        $query = mysqli_query($conn, $sql);
        
        header('Location:index.php');                                  
    }
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/bootstrap.css">
   
    <title>view</title>
</head>
<body class ="bg-dark"> <!--Chuyển màu nền cho body -->
    <div class = "container">
        <div class = "row" >
            <div class = "col-lg-9 m-auto"> <!--Căn ra giữa -->
                <div class = "card mt-5"><!-- form Xuống dưới -->
                            <div class =" card-title ">
                            <h3 class ="bg-success text-center" style="font-weight: 700;">THÔNG TIN HỒ SƠ</h3>
                            </div>
                        <div class = "card-body">
                            <form class="card-body" method="POST" enctype="multipart/form-data">
                                <div class = "form-row">
                                    <div class="col-md-6 mb-3">
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text" id="inputGroupPrepend2">Họ và tên</span>
                                            </div>
                                            
                                            <input type="text" class="form-control" name = "Hoten" id="validationDefaultUsername" placeholder="Nhập tên" aria-describedby="inputGroupPrepend2" value="<?php echo $row_up['hoten']; ?> "required>
                                        </div>
                                    </div>
 
                                    <div class=" col-md-6 mb-3">
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text" name = "Gioitinh" id="inputGroupPrepend2">Giới tính</span>
                                            </div>
                                            <!-- <select name="daymon" v
                                                <option>Math</option>
                                                <option>English</option>
                                            </select> -->
                                            
                                                <input  type="text" class="form-control"  name = "Gioitinh"    value="<?php echo $row_up['gioitinh']; ?>" required>

                                            </select>
                                            <!-- <select name="Gioitinh"  class="form-control " value="<
                                                <option >Nam</option>
                                                <option>Nữ</option>
                                               
                                            </select> -->
                                        </div>
                                    </div>
                                </div>
 
                                <div class = "form-row">
 
                                    <div class="col-md-6 mb-3">
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text" id="inputGroupPrepend2">Ngày sinh</span>
                                            </div>
                                            <input type="date" class="form-control" name ="Ngaysinh" id="validationDefaultUsername" placeholder="Nhập ngày sinh" aria-describedby="inputGroupPrepend2" value="<?php echo $row_up['ngaysinh']; ?>"required>
                                        </div>
                                    </div>
 
                                    <div class="col-md-3 mb-3">
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text" id="inputGroupPrepend2">Dân tộc</span>
                                            </div>
                                            <input type="text" class="form-control" name = "Dantoc" id="validationDefaultUsername" placeholder="Nhập tên" aria-describedby="inputGroupPrepend2" value="<?php echo $row_up['dantoc']; ?>" required>
                                        </div>
                                    </div>
 
                                    <div class="col-md-3 mb-3">
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text" id="inputGroupPrepend2">Tôn giáo</span>
                                            </div>
                                            <input type="text" class="form-control"name = "Tongiao" id="validationDefaultUsername" placeholder="Nhập tên" aria-describedby="inputGroupPrepend2" value="<?php echo $row_up['tongiao']; ?>" required>
                                        </div>
                                    </div>
 
                                </div>
 
                                <div class = "form-row">
                                    <div class="col-md-6 mb-3">
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text" id="inputGroupPrepend2">Nơi Sinh</span>
                                            </div>
                                            <input  type="text" class="form-control"  name = "Noisinh"    value="<?php echo $row_up['noisinh']; ?>" required>

                                        </div>
                                    </div>
 
                                    <div class="col-md-6 mb-3">
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text" id="inputGroupPrepend2">Năm tốt nghiệp</span>
                                            </div>
                                            <input  type="text" class="form-control"  name = "Namtotnghiep"    value="<?php echo $row_up['namtotnghiep']; ?>" required>


                                        </div>
                                    </div>
                                </div>
 
                                <div class = "form-row">
                                    <div class="col-md-6 mb-3">
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text" id="inputGroupPrepend2">Học lực lớp 12</span>
                                            </div>
                                            <input  type="text" class="form-control"  name = "Hocluc12"    value="<?php echo $row_up['hocluc12']; ?>" required>

                                        </div>
                                    </div>
 
                                    <div class="col-md-6 mb-3">
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text" id="inputGroupPrepend2">Hạnh kiểm lớp 12</span>
                                            </div>                                            
                                            <input  type="text" class="form-control"  name = "Hanhkiem12"    value="<?php echo $row_up['hanhkiem12']; ?>" required>

                                        </div>
                                    </div>
                                </div>
 
                                <div class = "form-row">
 
                                    <div class="col-md-4 mb-3">
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text" id="inputGroupPrepend2">Số CMND/CCCD</span>
                                            </div>
                                            <input type="text" class="form-control" name = "cmnd" id="validationDefaultUsername" placeholder="Nhập CMND" aria-describedby="inputGroupPrepend2" value="<?php echo $row_up['cmnd']; ?>" required>
                                        </div>
                                    </div>
 
                                    <div class="col-md-4 mb-3">
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text" id="inputGroupPrepend2">Ngày cấp</span>
                                            </div>
                                            <input type="date" class="form-control" name="Ngaycap" id="validationDefaultUsername" placeholder="Ngày cấp" aria-describedby="inputGroupPrepend2" value="<?php echo $row_up['ngaycap']; ?>" required>
                                        </div>
                                    </div>
 
                                    <div class="col-md-4 mb-3">
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text" id="inputGroupPrepend2">Nơi cấp</span>
                                            </div>
                                                <input  type="text" class="form-control"  name = "Noicap"    value="<?php echo $row_up['noicap']; ?>" required>

                                        </div>
                                    </div>
                                </div>
 
                                <div class = "form-row">
                                    <div class="col-md-12 mb-3">
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text" id="inputGroupPrepend2">Hộ khẩu thường trú</span>
                                            </div>
                                            <input type="text" class="form-control"  name = "Hokhau" id="validationDefaultUsername" placeholder="Nhập hộ khẩu thường trú" aria-describedby="inputGroupPrepend2" value="<?php echo $row_up['hokhau']; ?>" required>
                                        </div>
                                    </div>
                                </div>    
                                <p>Ghi rõ tên tỉnh (thành phố), huyện (quận) , xã (phường) , vào ô hộ khẩu thường trú </p>
                                <h6>Nơi học THPT hoặc tương đương (Ghi tên trường và nơi trường đóng : huyện quận , tỉnh thành phố) </h6>
                                <br/>
                                <div class = "form-row">
 
                                    <div class="col-md-1.5 mb-3">
                                       <h6 class = "text-center">Năm học</h6>
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                            <span class="input-group-text" id="inputGroupPrepend">Lớp 10</span>
                                            </div>
                                        </div>    
                                    </div>
 
                                    <div class="col-md-2 mb-3">
                                        <h6 class = "text-center">Mã Tỉnh</h6>
                                        <div class="input-group">
                                            <input type="text" name ="Matinh10" class="form-control" value="<?php echo $row_up['matinh10']; ?>" required>
                                        </div>
                                    </div>
 
                                    <div class="col-md-3.5 mb-3">
                                        <h6 class = "text-center">Tên Tỉnh/TP</h6>
                                        <div class="input-group">
                                            <input type="text" class="form-control" name ="Tentinh10" value="<?php echo $row_up['tentinh10']; ?>" required>
                                        </div>
                                    </div>
 
                                    <div class="col-md-2 mb-3">
                                        <h6 class = "text-center">Mã Trường</h6>
                                        <div class="input-group">
                                            <input type="text" class="form-control" name="Matruong10" value="<?php echo $row_up['matruong10']; ?>" required>
                                        </div>
                                    </div>
 
                                    <div class="col-md-3 mb-3">
                                        <h6 class = "text-center">Tên Trường</h6>
                                        <div class="input-group">
                                                <input type="text" class="form-control" name = "Tentruong10" value="<?php echo $row_up['tentruong10']; ?>" required>
                                        </div>
                                    </div>
 
                                </div>
 
                                <div class = "form-row">
 
                                    <div class="col-md-1.5 mb-3">
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                            <span class="input-group-text" id="inputGroupPrepend">Lớp 11</span>
                                            </div>
                                        </div>    
                                    </div>
 
                                    <div class="col-md-2 mb-3">
                                        <div class="input-group">
                                            <input type="text" class="form-control" name= "Matinh11" value="<?php echo $row_up['matinh11']; ?>" required>
                                        </div>
                                    </div>
 
                                    <div class="col-md-3.5 mb-3">
                                        <div class="input-group">
                                            <input type="text" class="form-control" name ="Tentinh11" value="<?php echo $row_up['tentinh11']; ?>" required>
                                        </div>
                                    </div>
 
                                    <div class="col-md-2 mb-3">
                                        <div class="input-group">
                                            <input type="text" class="form-control" name ="Matruong11" value="<?php echo $row_up['matruong11']; ?>" required>
                                        </div>
                                    </div>
 
                                    <div class="col-md-3 mb-3">
                                        <div class="input-group">
                                                <input type="text" class="form-control" name ="Tentruong11" value="<?php echo $row_up['tentruong11']; ?>" required>
                                        </div>
                                    </div>
 
                                </div>
 
                                <div class = "form-row">
 
                                    <div class="col-md-1.5 mb-3">
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                            <span class="input-group-text" id="inputGroupPrepend">Lớp 12</span>
                                            </div>
                                        </div>    
                                    </div>
 
                                    <div class="col-md-2 mb-3">
                                        <div class="input-group">
                                            <input type="text" class="form-control" name ="Matinh12" value="<?php echo $row_up['matinh12']; ?>" required>
                                        </div>
                                    </div>
 
                                    <div class="col-md-3.5 mb-3">
                                        <div class="input-group">
                                            <input type="text" class="form-control" name ="Tentinh12" value="<?php echo $row_up['tentinh12']; ?>" required>
                                        </div>
                                    </div>
 
                                    <div class="col-md-2 mb-3">
                                        <div class="input-group">
                                            <input type="text" class="form-control" name="Matruong12"value="<?php echo $row_up['matruong12']; ?>" required>
                                        </div>
                                    </div>
 
                                    <div class="col-md-3 mb-3">
                                        <div class="input-group">
                                                <input type="text" class="form-control" name = "Tentruong12" value="<?php echo $row_up['tentruong12']; ?>" required>
                                        </div>
                                    </div>
 
                                </div>
 
                                <div class="form-row">
                                    <div class="col-md-9">
                                        <lable>Đối tượng ưu tiên tuyển sinh (Thuộc đối tượng nào thì chọn đối tượng bên phải)</lable>
 
                                    </div>
                                    <div class="col-md-2">                                        
                                        <input  type="text" class="form-control"  name = "DoituongUT"    value="<?php echo $row_up['doituongut']; ?>" required>

                                    </div>
                                </div> 
                                <br>
                                <div class="form-row">
                                    <div class="col-md-9">
                                        <lable>Khu vực ưu tiên tuyển sinh (Thuộc đối tượng nào thì chọn  kí hiệu của khu vực (kv1,kv2..) vào ô khu vực ưu tiên)</lable>
 
                                    </div>
                                    <br>
                                    <div class="col-md-2">                        
                                        <input  type="text" class="form-control"  name = "KhuvucUT"    value="<?php echo $row_up['khuvucut']; ?>" required>
                                    </div>
                                </div>
                                
                                <br>
                                 <div class = "form-row">
                                    <div class="col-md-12 mb-3">
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text" id="inputGroupPrepend2">Địa chỉ liên hệ</span>
                                            </div>
                                            <input type="text" class="form-control"  name = "DiachiLH"  placeholder="Nhập địa chỉ"  value="<?php echo $row_up['diachilh']; ?>" required>
                                        </div>
                                    </div>
                                </div> 
 
                                <div class = "form-row">
                                    <div class="col-md-6 mb-3">
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text" id="inputGroupPrepend2">Điện thoại thí sinh</span>
                                            </div>
                                            <input type="text" class="form-control" name = "Sdths" id="validationDefaultUsername" placeholder="Nhập SDT" aria-describedby="inputGroupPrepend2" value="<?php echo $row_up['sdths']; ?>" required>
                                        </div>
                                    </div>
 
                                    <div class=" col-md-6 mb-3">
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text" name = "Sdtph" id="inputGroupPrepend2">Điện thoại phụ huynh</span>
                                            </div>
                                            <input type="text" class="form-control" name = "Sdtph" id="validationDefaultUsername" placeholder="Nhập SDT" aria-describedby="inputGroupPrepend2" value="<?php echo $row_up['sdtph']; ?>" required>
                                        </div>
                                    </div>
                                </div>    
                                
                                <br>
                                <br>
                                <br>
 
                                <h3 class ="bg-success text-center" style="font-weight: 700;">THÔNG TIN ĐĂNG KÝ</h3>
                                <br>
                                <lable>Sau khi đã đọc và hiểu rõ các quy định vể tiêu chí và điều kiện xét tuyển của nhà trường , tôi đồng ý xét tuyển học bạ vào trình độ đại học như sau (Chọn phương thức xét tuyển)</lable>
                                <br>
                                <br>
                                <div class = "form-group" value="<?php echo $row_up['Dtb12']; ?>">
                                <input type="radio"  name="Dtb12" checked = "checked" value = " TB 3môn lớp 12">
                                <label class = "radio-lable"> Tuyển bằng tổng điểm trung bình lớp 12 theo tổng điểm 3 môn</label>
                                <br>
                                <input type="radio" name="Dtb12" value ="trung bình (HK1 , HK2 lớp 11  )">
                                <label for="vehicle2">Tuyển bằng tổng điểm trung bình (HK1 , HK2 lớp 11  )</label><br>
                                </div>
                                <button class ="btn btn-primary btn-center" type ="submit" name = 'save' ><a href="index.php" style="color:white; text-decoration:none;">Thoát</a></button>
                            </form>
                        </div>
                 </div>
            </div>
        
        </div>
    </div>
</body>
</html>
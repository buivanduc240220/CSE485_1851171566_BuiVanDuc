<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Registration</title>
    <link rel="stylesheet" type="text/css" href="css/signin.css">
</head>
<body>
    <center>
    <div class="header">
    <h2>Login</h2>
    </div>
    </center>	
 
  <form method="post" action="login.php" >
  <?php if (isset($_GET['error'])) { ?>
     		<p class="error"><?php echo $_GET['error']; ?></p>
     	<?php } ?>
    <div class="input-group">           
     <label >Username</label>
     <input type="text" name="uname">
     </div>
 
 
     <div class="input-group">   
     <label >Password</label>
     <input type="password" name="password">
     </div>
 
     <div class="input-group">   
     <a href="webkhoadk.php"><button type="submit" name="login" class="btn">Login</button></a>
     <button type="submit" name="quaylai" class="btn"><a href="webkhoa.php" style="color: white; text-decoration:none;">Cancel</a></button>
     </div>
     <p>
         Not yet a member ?<a href="signup.php">Sign up</a>
     </p>
 </form>
 
</body>
</html>

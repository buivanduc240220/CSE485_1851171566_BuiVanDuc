
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Khoa Cong Nghe Thong Tin</title>
</head>
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
<body>
        <!-- <?php
        // $conn = mysqli_connect('localhost','root','','cuoiky');
        //     if(!$conn){
        //         die('Lỗi! Không thể kết nối');
        //         exit();
        //     }

        //     $id = $_GET['id'];
        //     $sql_up = "SELECT * FROM register_signin WHERE id = $id";
        //     $query_up = mysqli_query($conn, $sql_up);
        //     $row_up = mysqli_fetch_assoc($query_up);
        ?> -->
        <!-- header top -->
    <div class="globalheader">
        <div class="header_top">
            <div class="label_tlu">
                <a href="http://www.tlu.edu.vn">Trường Đại học Thủy Lợi -TLU</a>
            </div>
            <div class="thanghang" id="text"><p>(+) |</p></div>
            <div class="thanghang" id="language">
                <span class="language-text"> Ngôn ngữ: &nbsp;&nbsp;&nbsp;&nbsp;</span>
                    <a href="#" title="Tiếng Việt"><img src="images/vietnam.png" alt="Tiếng Việt"></a>
                    <a href="#" title="Tiếng Anh" ><img src="images/tienganh.png" alt="Tiếng Anh"></a>
            </div>
            <div class="thanghang" id="search-container">
                <input type="text" placeholder="Tìm kiếm" name="search">
                <button type="submit"><i class="fa fa-search"></i></button>
            </div>
            <div class="thanghang">
                <!-- <p><?php //echo $row_up['uname'];?></p> -->
            </div>
        </div>
    </div>




    <div class="divborder">
    <div id="header">
        <div class="containerr">
            <div class="logo" ><a href=""><img src="images/logo.jpg" alt=""></a></div>
            <!-- <i class="fas fa-search"></i>
            <input name="" type="text" id="tbxHomekeyword" class="input-text" placeholder="Tìm kiếm" autocomplete="off">
            <input type="button" value="Tìm" class="input-submit" ng-click="formClick()">
        --> <div class="contact-tlu">
                <ul>
                    <li>
                        <div class="contact-icon">
                            <span<i class="fas fa-paper-plane" id="plane"></i></span>
                        </div>
                        <div class="contact-text">
                            <label>Email:</label>
                            <span>vpkcntt@tlu.edu.vn</span>
                        </div>
                    </li>
                    <li>
                        <div class="contact-icon">
                            <span<i class="fas fa-phone-alt" id="phone"></i></span>
                        </div>
                        <div class="contact-text">
                            <label>Call:</label>
                            <span>0243 563 2211</span>
                        </div>
                    </li>
                    <li>
                        <a href="webkhoa.php" class="register">Logout</a>
                    </li>
                </ul>
            </div>    
        </div>
    </div>

    <!-- ////////////////////////////// -->
    <!-- <div>
        <nav class="navbar navbar-expand-lg navbar-light" style="background-color: #ffffff;height: 30px;font-size: 16px;">
            <a class="navbar-brand" href="#">Navbar</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavDropdown">
              <ul class="navbar-nav">
                <li class="nav-item active">
                  <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
                </li>   
                <li class="nav-item">
                  <a class="nav-link" href="#">Features</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="#">Pricing</a>
                </li>
                <li class="nav-item dropdown">
                  <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Dropdown link
                  </a>
                  <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                    <a class="dropdown-item" href="#">Action</a>
                    <a class="dropdown-item" href="#">Another action</a>
                    <a class="dropdown-item" href="#">Something else here</a>
                  </div>
                </li>
              </ul>
            </div>
          </nav>
    </div> -->

    <div id="nav">
        <div class="containerr">
            <ul class="menu">
                <li class="home"><a href="/" ><i class="fa fa-home"></i></a></li>
                <li class=""><a href="/">Trang chủ</a></li>
                <li class="has_sub"><a href="/">Giới thiệu</a>
                    <div class="nav_sub">
                        <ul class="submenu">
                            <li><a  href="">Logo Khoa CNTT</a></li>     
                            <li><a  href="">Lời chào mừng</a></li>
                            <li><a  href="">Tổ chức</a></li> 
                            <li><a  href="">Hợp tác liên kết</a></li>
                        </ul>
                    </div>
                </li>
                <li class="has_sub"><a href="/">Nghiên cứu khoa học</a>
                    <div class="nav_sub">
                        <ul class="submenu">                                
                                    <li><a href="">Các đề tài, dự án</a></li>                        
                                    <li><a href="">Thông tin seminar</a></li>                        
                                    <li><a href="">Công trình công bố</a></li>                        
                                    <li><a href="">Các phòng thí nghiệm</a></li>                        
                        </ul>
                    </div>
                </li>
                <li class="has_sub"><a href="/">Đào tạo</a>
                    <div class="nav_sub">
                        <ul class="submenu">                                
                                <li><a id="" href="">Đào tạo đại học</a></li>                                
                                <li><a id="" href="">Đào tạo sau đại học</a></li>
                                <li><a id="" href="">Chuẩn đầu ra</a></li>                            
                                <li><a id="" href="">Định hướng ngành nghề</a></li>                            
                                <li><a id="" href="">Mô hình đào tạo</a></li>                            
                                <li><a id="" href="">Đề cương môn học</a></li>                                                  
                        </ul>
                    </div>
                </li>
                <li class="has_sub"><a href="/">Bộ môn - trung tâm</a>
                    <div class="nav_sub">
                        <ul class="submenu">                                
                                <li><a  href="">CN phần mềm</a></li>                                
                                <li><a  href="">Hệ thống thông tin</a></li>                            
                                <li><a  href="">Khoa học máy tính</a></li>                            
                                <li><a  href="">Kỹ thuật máy tính và mạng</a></li>                            
                                <li><a  href="">Toán học</a></li>                            
                                <li><a  href="">Tin học và Kỹ thuật tính toán</a></li>                            
                                <li><a  href="">Trung tâm tin học</a></li>                                                                              
                        </ul>
                    </div>
                </li>
                <li class="has_sub"><a href="/">Sinh Viên</a>
                    <div class="nav_sub">
                        <ul class="submenu">                                
                                <li><a id="" href="">Tài liệu sinh viên</a></li>
                                <li><a id="" href="">Tổ tư vấn học tập</a></li>                            
                                <li><a id="" href="">Biểu mẫu ĐATN</a></li>                            
                                <li><a id="" href="">Luận văn tốt nghiệp</a></li>                                                                                                          
                        </ul>
                    </div>
                </li>
                <li class="has_sub"><a href="/">Tin tức</a>
                    <div class="nav_sub">
                        <ul class="submenu">                                
                                <li><a id=" " href="">Sự kiện</a></li>                                
                                <li><a id=" " href="">CSE trên báo</a></li>                                                                                                        
                        </ul>
                    </div>
                </li>
                <li class="has_sub"><a href="/">Thông báo</a>
                    <div class="nav_sub">
                        <ul class="submenu">                                
                                <li><a id=" " href="">Thông báo</a></li>                                
                                <li><a id=" " href="">TB Đào tạo</a></li>                            
                                <li><a id=" " href="">Nghiên cứu khoa học</a></li>                            
                                <li><a id=" " href="">Tuyển dụng</a></li>                            
                                <li><a id=" " href="">Học bổng</a></li>                            
                                <li><a id=" " href="">Thông báo khác</a></li>                                                                                              
                        </ul>
                    </div>
                </li>
                <li class="has_sub" ><a href="/"style="color: red;"><i class="fas fa-user-cog"></i>Admin</a>
                    <div class="nav_sub">
                        <ul class="submenu">                                
                                <li><a id=" " href="index.php"><i class="fa fa-user" aria-hidden="true"></i> Quản lý hồ sơ học bạ</a></li>                                
                                <li><a id=" " href=""><i class="fas fa-newspaper"></i> Quản lý tin tức</a></li>                                                                                        
                        </ul>
                    </div>
                </li>
            </ul>
        </div>
    </div>




    <!-- //////////////////                   start -->
    <!-- <div>
        <div class="main_nav">
            <ul class="list_nav">
                <li class="home"><a href="/" style="font-size: 24px"><i class="fa fa-home"></i></a></li>
                <li class=""><a href="/" style="color: red;">Trang chủ</a></li>

                <li class="has_sub"><a href="/">Giới thiệu</a>
                    <div class="nav_sub">
                        <ul class="list_sub">
                            
                                    <li><a  href="http://cse.tlu.edu.vn/logo-cua-khoa">Logo Khoa CNTT</a></li>
                                
                                    <li><a  href="http://cse.tlu.edu.vn/loi-chao-mung">Lời chào mừng</a></li>
                                
                                    <li><a  href="http://cse.tlu.edu.vn/co-cau-to-chuc">Tổ chức</a></li>
                                
                                    <li><a  href="http://cse.tlu.edu.vn/hop-tac-quoc-te">Hợp tác liên kết</a></li>
                        </ul>
                        </div>
                </li>
                <li class="has_sub"><a href="/">Nghiên cứu khoa học</a></li>
                <li class="has_sub"><a href="/">Đào tạo</a></li>
                <li class="has_sub"><a href="/">Bộ môn trung âm</a></li>
                <li class="has_sub"><a href="/">Sinh Viên</a></li>
                <li class="has_sub"><a href="/">Tin tức</a></li>
                <li class="has_sub"><a href="/">Thông báo</a></li>
                <li class="has_sub"><a href="/">Liên hệ</a></li>

            </ul>
        </div>
    </div>          ////////////////          end              -->
    

    <!-- <div>
        <nav class="navmain">
        <ul class="list-nav">
            <li class="home hidden-xs"><a href="/"><i class="fa-home2"></i></a></li>
            <li class="homesp"><a href="/">Trang chủ</a></li>
            
            
                    <li class="has-sub"><a  href="http://cse.tlu.edu.vn/gioi-thieu">Giới thiệu</a>
                        
                        <div class="nav-sub">
                        <ul class="list-sub">
                            
                                    <li><a  href="http://cse.tlu.edu.vn/logo-cua-khoa">Logo Khoa CNTT</a></li>
                                
                                    <li><a id="" href="http://cse.tlu.edu.vn/loi-chao-mung">Lời chào mừng</a></li>
                                
                                    <li><a id="" href="http://cse.tlu.edu.vn/co-cau-to-chuc">Tổ chức</a></li>
                                
                                    <li><a id="" href="http://cse.tlu.edu.vn/hop-tac-quoc-te">Hợp tác liên kết</a></li>
                                
                        </ul>
                        </div>
                        
                    </li>
                
                    <li class="has-sub"><a id="" href="http://cse.tlu.edu.vn/khoa-hoc-cong-nghe">Nghiên cứu khoa học</a>
                        
                        <div class="nav-sub">
                        <ul class="list-sub">
                            
                                    <li><a id="" href="http://cse.tlu.edu.vn/cac-de-tai-du-an">Các đề tài, dự án</a></li>
                                
                                    <li><a id="" href="http://cse.tlu.edu.vn/thong-tin-seminar">Thông tin seminar</a></li>
                                
                                    <li><a id="" href="http://cse.tlu.edu.vn/cac-cong-trinh-cong-bo">Công trình công bố</a></li>
                                
                                    <li><a id="" href="http://cse.tlu.edu.vn/cac-phong-thi-nghiem">Các phòng thí nghiệm</a></li>
                                
                        </ul>
                        </div>
                        
                    </li>
                
                    <li class="has-sub"><a id="" href="http://cse.tlu.edu.vn/dao-tao">Đào tạo</a>
                        
                        <div class="nav-sub">
                        <ul class="list-sub">
                            
                                    <li><a id="" href="http://cse.tlu.edu.vn/dao-tao-dai-hoc-chinh-quy">Đào tạo đại học</a></li>
                                
                                    <li><a id="" href="http://cse.tlu.edu.vn/dao-tao-sau-dai-hoc">Đào tạo sau đại học</a></li>

                                    <li><a id="" href="http://cse.tlu.edu.vn/%c4%90%c3%a0o-t%e1%ba%a1o/Chu%e1%ba%a9n-%c4%91%e1%ba%a7u-ra">Chuẩn đầu ra</a></li>
                                
                                    <li><a id="" href="http://cse.tlu.edu.vn/dao-tao-tien-si">Định hướng ngành nghề</a></li>
                                
                                    <li><a id="" href="http://cse.tlu.edu.vn/mo-hinh-dao-tao">Mô hình đào tạo</a></li>
                                
                                    <li><a id="" href="http://cse.tlu.edu.vn/dao-tao/de-cuong-mon-hoc">Đề cương môn học</a></li>
                                
                        </ul>
                        </div>
                        
                    </li>
                
                    <li class="has-sub"><a id="" href="http://cse.tlu.edu.vn/bo-mon-trung-tam">Bộ môn-Trung tâm</a>
                        
                        <div class="nav-sub">
                        <ul class="list-sub">
                            
                                    <li><a id="" href="http://cse.tlu.edu.vn/cong-nghe-phan-mem">CN phần mềm</a></li>
                                
                                    <li><a id="" href="http://cse.tlu.edu.vn/he-thong-thong-tin">Hệ thống thông tin</a></li>
                                
                                    <li><a id="" href="http://cse.tlu.edu.vn/khoa-hoc-may-tinh">Khoa học máy tính</a></li>
                                
                                    <li><a id="" href="http://cse.tlu.edu.vn/ky-thuat-may-tinh-va-mang">Kỹ thuật máy tính và mạng</a></li>
                                
                                    <li><a id="" href="http://cse.tlu.edu.vn/bo-mon-toan-hoc">Toán học</a></li>
                                
                                    <li><a id="" href="http://cse.tlu.edu.vn/B%e1%bb%99-m%c3%b4n-Trung-t%c3%a2m/Tin-h%e1%bb%8dc-v%c3%a0-k%e1%bb%b9-thu%e1%ba%adt-t%c3%adnh-to%c3%a1n">Tin học và Kỹ thuật tính toán</a></li>
                                
                                    <li><a id="" href="http://cse.tlu.edu.vn/trung-tam-tin-hoc">Trung tâm tin học</a></li>
                                
                        </ul>
                        </div>
                        
                    </li>
                
                    <li class="has-sub"><a id="dnn_ctr497_ViewCmsMenu_ctl00_rptMn0_hpl_4" href="http://cse.tlu.edu.vn/sinh-vien">Sinh viên</a>
                        
                        <div class="nav-sub">
                        <ul class="list-sub">
                            
                                    <li><a id="" href="http://cse.tlu.edu.vn/tai-lieu-sinh-vien">Tài liệu sinh viên</a></li>
                                
                                    <li><a id="" href="http://cse.tlu.edu.vn/to-tu-van-hoc-tap">Tổ tư vấn học tập</a></li>
                                
                                    <li><a id="" href="http://cse.tlu.edu.vn/Sinh-vi%c3%aan/Bi%e1%bb%83u-m%e1%ba%abu-%c4%90ATN">Biểu mẫu ĐATN</a></li>
                                
                                    <li><a id="" href="http://cse.tlu.edu.vn/Sinh-vi%c3%aan/Lu%e1%ba%adn-v%c4%83n-t%e1%bb%91t-nghi%e1%bb%87p">Luận văn tốt nghiệp</a></li>
                                
                        </ul>
                        </div>
                        
                    </li>
                
                    <li class="has-sub"><a id=" " href="http://cse.tlu.edu.vn/tin-tuc-thong-bao">Tin tức</a>
                        
                        <div class="nav-sub">
                        <ul class="list-sub">
                            
                                    <li><a id=" " href="http://cse.tlu.edu.vn/su-kien">Sự kiện</a></li>
                                
                                    <li><a id=" " href="http://cse.tlu.edu.vn/cse-tren-bao">CSE trên báo</a></li>
                                
                        </ul>
                        </div>
                        
                    </li>
                
                    <li class="has-sub"><a id=" " href="http://cse.tlu.edu.vn/tin-thong-bao">Thông báo</a>
                        
                        <div class="nav-sub">
                        <ul class="list-sub">
                            
                                    <li><a id=" " href="http://cse.tlu.edu.vn/thong-bao-sinh-vien">Thông báo</a></li>
                                
                                    <li><a id=" " href="http://cse.tlu.edu.vn/thong-bao-dao-tao">TB Đào tạo</a></li>
                                
                                    <li><a id=" " href="http://cse.tlu.edu.vn/thong-bao-nghien-cuu-khoa-hoc">Nghiên cứu khoa học</a></li>
                                
                                    <li><a id=" " href="http://cse.tlu.edu.vn/tuyen-dung">Tuyển dụng</a></li>
                                
                                    <li><a id=" " href="http://cse.tlu.edu.vn/thong-bao-hoc-bong">Học bổng</a></li>
                                
                                    <li><a id=" " href="http://cse.tlu.edu.vn/thong-bao-khac">Thông báo khác</a></li>
                                
                        </ul>
                        </div>
                        
                    </li>
                
                    <li class="has-sub"><a id="" href="http://cse.tlu.edu.vn/lien-he">Liên hệ</a>
                    </li>
                    
        </ul>
        </nav>
    </div> -->

    <!-- ////////////////////////// -->
<!-- MMMMMMMMMMMMMMMMMMAINNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN -->
    <div class="container">
        <div style="height: 40px;"></div>
        <div class="row">
            <div class="col-md-9">
                <div class="slide_image">
                    <div class="carousel slide" id="carousel-773094">
                        <ol class="carousel-indicators">
                            <li data-slide-to="0" data-target="#carousel-773094" class="active"></li>
                            <li data-slide-to="1" data-target="#carousel-773094"></li>
                            <li data-slide-to="2" data-target="#carousel-773094"></li>
                            <li data-slide-to="3" data-target="#carousel-773094"></li>
                            <li data-slide-to="4" data-target="#carousel-773094"></li>
                            <li data-slide-to="5" data-target="#carousel-773094"></li>
        
                        </ol>
                        <div class="carousel-inner">
                            <div class="carousel-item active">
                                <img class="d-block w-100" style="height: 315px;" alt="Carousel Bootstrap First" src="images/anh1.jpg" />
                            </div>
                            <div class="carousel-item">
                                <img class="d-block w-100" style="height: 315px;" alt="Carousel Bootstrap Second" src="images/anh2.jpg" />
                            </div>
                            <div class="carousel-item">
                                <img class="d-block w-100" style="height: 315px;" alt="Carousel Bootstrap Third" src="images/anh5.jpg" />
                            </div>
                            <div class="carousel-item">
                                <img class="d-block w-100" style="height: 315px;" alt="Carousel Bootstrap Forth" src="images/anh6.jpg" />
                            </div>
                            <div class="carousel-item">
                                <img class="d-block w-100" style="height: 315px;" alt="Carousel Bootstrap Fifth" src="images/anh3.jpg" />
                            </div>
                            <div class="carousel-item">
                                <img class="d-block w-100" style="height: 315px;" alt="Carousel Bootstrap Sixth" src="images/anh4.jpg" />
                            </div>
                        </div> 
        
                        <a class="carousel-control-prev" href="#carousel-773094" data-slide="prev"><span class="carousel-control-prev-icon"></span> <span class="sr-only">Trước</span></a> <a class="carousel-control-next" href="#carousel-773094" data-slide="next"><span class="carousel-control-next-icon"></span> <span class="sr-only">Tiếp theo</span></a>
        
                    </div>   
                </div>
                <div class="news">
                    <div class="container">
                        <div class="row">
                            <div id="item_news" class="col-md-4" style="border-left: 0.5px dotted gray ;border-right: 0.5px dotted gray;">
                                <img src="images/tintuc1.jpg" alt="">
                                <a href="" style="font-weight: bold;"><p>Lời chào mừng</p></a>
                            </div>
                            <div id="item_news" class="col-md-4" style="border-right: 0.5px dotted gray;">
                                <img src="images/tintuc2.jpg" alt="">
                                <a href=""style="font-weight: bold;"><p>Giảng viên</p></a>
                            </div>
                            <div id="item_news" class="col-md-4" style="border-right: 0.5px dotted gray;">
                                <img src="images/tintuc3.jpg" alt="">
                                <a href=""style="font-weight: bold;"><p>Đào tạo</p></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="hocba">
                    <a href="add.php"><img src="images/hocba.img" style="width: 300px; height:250px ;" alt="hocba"></a>
                </div>
            </div>
        </div>
    </div>
    
     <div class="footer">
        <div class="container">
            <div class="footer__bot">
                <img id="image_bot" src="images/image_bot.jpg" alt="">
                <p style="color: white;">© 2017 Khoa Công nghệ thông tin - Đại học Thủy lợi<br>
                Địa chỉ: nhà C1, Đại học Thủy lợi, 175 Tây Sơn, Đống Đa, Hà Nội. Điện thoại: (+84)-024&nbsp;3 5632211. Email: <a class="ui-link-white" href="#">vpkcntt@tlu.edu.vn</a></p>
            </div>
        </div>
    </div>

    

 


    <script src="js/jquery-3.5.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</body>
</html>


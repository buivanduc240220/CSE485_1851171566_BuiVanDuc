<?php
    require('includes/config.php'); 
 
    if(isset($_POST['save'])){
        $HoTen = $_POST['HoTen'];
        $GioiTinh  = $_POST['GioiTinh'];
        $NgaySinh = $_POST['NgaySinh'];
        $NoiSinh = $_POST['NoiSinh'];
        $DanToc = $_POST['DanToc'];
        $TonGiao = $_POST['TonGiao'];
        $NamTotNghiep = $_POST['NamTotNghiep'];
        $HocLuc12 = $_POST['HocLuc12'];
        $HanhKiem12 = $_POST['HanhKiem12'];
        $Cmnd = $_POST['Cmnd'];
        $NgayCap = $_POST['NgayCap'];
        $NoiCap = $_POST['NoiCap'];
        $HoKhau = $_POST['HoKhau'];
        $MaTinh10 = $_POST['MaTinh10'];
        $MaTinh11 = $_POST['MaTinh11'];
        $MaTinh12 = $_POST['MaTinh12'];
        $TenTinh10 = $_POST['TenTinh10'];
        $TenTinh11 = $_POST['TenTinh11'];
        $TenTinh12 = $_POST['TenTinh12'];
        $MaTruong10 = $_POST['MaTruong10'];
        $MaTruong11 = $_POST['MaTruong11'];
        $MaTruong12 = $_POST['MaTruong12'];
        $TenTruong10 = $_POST['TenTruong10'];
        $TenTruong11 = $_POST['TenTruong11'];
        $TenTruong12 = $_POST['TenTruong12'];
        $DoiTuongUT = $_POST['DoiTuongUT'];
        $KhuVucUT = $_POST['KhuVucUT'];
        $DiaChiLH = $_POST['DiaChiLH'];
        $Sdths = $_POST['Sdths'];
        $Sdtph = $_POST['Sdtph'];
        $Dtb12 = $_POST['Dtb12'];
      
        
        $sql = "INSERT INTO information ( hoten , gioitinh , ngaysinh,  noisinh ,dantoc ,tongiao , namtotnghiep , hocluc12 , hanhkiem12 , cmnd , ngaycap , noicap , hokhau ,matinh10 , matinh11 , matinh12 , tentinh10 , tentinh11 , tentinh12 , matruong10 , matruong11 , matruong12 , tentruong10 , tentruong11 , tentruong12 , doituongut , khuvucut , diachilh , sdths , sdtph , dtb12  ) VALUES ('$HoTen'  , '$GioiTinh' , '$NgaySinh' , '$NoiSinh' , '$DanToc' , '$TonGiao' , '$NamTotNghiep' , '$HocLuc12' , '$HanhKiem12' , '$Cmnd' , '$NgayCap' , '$NoiCap' , '$HoKhau' , '$MaTinh10' , '$MaTinh11' , '$MaTinh12' , '$TenTinh10' , '$TenTinh11' , '$TenTinh12' , '$MaTruong10' , '$MaTruong11' , '$MaTruong12' , '$TenTruong10' , '$TenTruong11' , '$TenTruong12' , '$DoiTuongUT' , '$KhuVucUT' , '$DiaChiLH' , '$Sdths' , '$Sdtph' , '$Dtb12' )";
        $query = mysqli_query($conn, $sql);
        
        header('Location:index.php');                                  
    }
?>
 
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/bootstrap.css">
   
    <title>add</title>
</head>
<body class =""> <!--Chuyển màu nền cho body -->
    <div class = "container">
        <div class = "row" >
            <div class="col-md-3">
                <div class="card mt-5 ">
                    <div class="img" ><a href=""><img src="images/li1.jpg" alt="" style="height:63px"></div></a>
                    <div class="img" ><a href=""><img src="images/li2.jpg" alt="" style="height:63px"></div></a>
                    <div class="img" ><a href=""><img src="images/li3.jpg" alt="" style="height:63px"></div></a>
                    <div class="img" ><a href=""><img src="images/li4.jpg" alt="" style="height:63px"></div></a>
                    <div class="img" ><a href=""><img src="images/li5.jpg" alt="" style="height:63px"></div></a>
                </div>
            </div>
            <div class = "col-lg-9 "> <!--Căn ra giữa -->
                <div class = "card mt-5"><!-- form Xuống dưới -->
                            <div class =" card-title " >
                                <h3 class ="bg-success text-center" style="font-weight: 700;">THÔNG TIN HỒ SƠ</h3>
                            </div>
                        <div class = "card-body">
                            <form class="card-body" method="POST" enctype="multipart/form-data">
                                <div class = "form-row">
                                    <div class="col-md-6 mb-3">
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text">Họ và tên</span>
                                            </div>
                                            <input type="text" class="form-control" name = "HoTen" placeholder="Nhập tên" aria-describedby="inputGroupPrepend2" required>
                                        </div>
                                    </div>
 
                                    <div class=" col-md-6 mb-3">
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text" name = "GioiTinh" >Giới tính</span>
                                            </div>
                                            <select name="GioiTinh"  class="form-control " >
                                                <option >Nam</option>
                                                <option>Nữ</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
 
                                <div class = "form-row">
 
                                    <div class="col-md-6 mb-3">
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text" >Ngày sinh</span>
                                            </div>
                                            <input type="date" class="form-control" name ="NgaySinh"  placeholder="Nhập ngày sinh" aria-describedby="inputGroupPrepend2" required>
                                        </div>
                                    </div>
 
                                    <div class="col-md-3 mb-3">
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text" >Dân tộc</span>
                                            </div>
                                            <input type="text" class="form-control" name = "DanToc"  placeholder="Nhập dân tộc" aria-describedby="inputGroupPrepend2" required>
                                        </div>
                                    </div>
 
                                    <div class="col-md-3 mb-3">
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text">Tôn giáo</span>
                                            </div>
                                            <input type="text" class="form-control"name = "TonGiao" placeholder="Nhập tôn giáo" aria-describedby="inputGroupPrepend2" required>
                                        </div>
                                    </div>
 
                                </div>
 
                                <div class = "form-row">
                                    <div class="col-md-6 mb-3">
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text">Nơi Sinh</span>
                                            </div>
                                            <select name="NoiSinh" class="form-control "required>
                                                <option value ="0">--chọn tỉnh--</option>
                                                <option>Hà Nội</option>
                                                <option>TP HCM</option>
                                                <option>Thanh Hoá</option>
                                                <option>Hải Dương</option>
                                                <option>Ninh Bình</option>
                                                <option>Huế</option>
                                                <option>Đà Nẵng</option>
                                            </select>
                                        </div>
                                    </div>
 
                                    <div class="col-md-6 mb-3">
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text" >Năm tốt nghiệp</span>
                                            </div>
                                            <select name="NamTotNghiep" class="form-control "required>
                                                <option value ="0" >--chọn năm--</option>
                                                <option>2000</option>
                                                <option>1999</option>
                                                <option>1998</option>
                                                <option>1997</option>
                                                <option>1996</option>
                                                <option>1995</option>
                                                <option>1994</option>
                                                <option>1993</option>
                                                <option>1992</option>
                                                <option>1991</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
 
                                <div class = "form-row">
                                    <div class="col-md-6 mb-3">
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text" >Học lực lớp 12</span>
                                            </div>
                                            <select name="HocLuc12" class="form-control  "required>
                                                <option value ="0" >-chọn-</option>
                                                <option>Giỏi</option>
                                                <option>Khá</option>
                                            </select>
                                        </div>
                                    </div>
 
                                    <div class="col-md-6 mb-3">
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text">Hạnh kiểm lớp 12</span>
                                            </div>
                                            <select name="HanhKiem12" class="form-control "required>
                                                <option value ="0" >-chọn-</option>
                                                <option>Tốt</option>
                                                <option>Khá</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
 
                                <div class = "form-row">
 
                                    <div class="col-md-4 mb-3">
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text">Số CMND/CCCD</span>
                                            </div>
                                            <input type="text" class="form-control" name = "Cmnd" placeholder="Nhập CMND"  required>
                                        </div>
                                    </div>
 
                                    <div class="col-md-4 mb-3">
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text" >Ngày cấp</span>
                                            </div>
                                            <input type="date" class="form-control" name="NgayCap"  placeholder="Ngày cấp"  required>
                                        </div>
                                    </div>
 
                                    <div class="col-md-4 mb-3">
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text">Nơi cấp</span>
                                            </div>
                                            <select name="NoiCap" class="form-control " required>
                                                <option value ="0" >--chọn tỉnh--</option>
                                                <option>Hà Nội</option>
                                                <option>TP HCM</option>
                                                <option>Thanh Hoá</option>
                                                <option>Hải Dương</option>
                                                <option>Ninh Bình</option>
                                                <option>Huế</option>
                                                <option>Đà Nẵng</option>                                                                                            
                                            </select>
                                        </div>
                                    </div>
                                </div>
 
                                <div class = "form-row">
                                    <div class="col-md-12 mb-3">
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text">Hộ khẩu thường trú</span>
                                            </div>
                                            <input type="text" class="form-control"  name = "HoKhau" placeholder="Nhập hộ khẩu thường trú" aria-describedby="inputGroupPrepend2" required>
                                        </div>
                                    </div>
                                </div>    
                                <p>Ghi rõ tên tỉnh (thành phố), huyện (quận), xã (phường), vào ô hộ khẩu thường trú </p>
                                <h6>Nơi học THPT hoặc tương đương (Ghi tên trường và nơi trường đóng: huyện, quận, tỉnh, thành phố) </h6>
                                <br/>
                                <div class = "form-row">
 
                                    <div class="col-md-1.5 mb-3">
                                       <h6 class = "text-center">Năm học</h6>
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                            <span class="input-group-text" >Lớp 10</span>
                                            </div>
                                        </div>    
                                    </div>
 
                                    <div class="col-md-2 mb-3">
                                        <h6 class = "text-center">Mã Tỉnh</h6>
                                        <div class="input-group">
                                            <input type="text" name ="MaTinh10" class="form-control"  required>
                                        </div>
                                    </div>
 
                                    <div class="col-md-3.5 mb-3">
                                        <h6 class = "text-center">Tên Tỉnh/TP</h6>
                                        <div class="input-group">
                                            <input type="text" class="form-control" name ="TenTinh10"  required>
                                        </div>
                                    </div>
 
                                    <div class="col-md-2 mb-3">
                                        <h6 class = "text-center">Mã Trường</h6>
                                        <div class="input-group">
                                            <input type="text" class="form-control" name="MaTruong10" required>
                                        </div>
                                    </div>
 
                                    <div class="col-md-3 mb-3">
                                        <h6 class = "text-center">Tên Trường</h6>
                                        <div class="input-group">
                                                <input type="text" class="form-control" name = "TenTruong10" required>
                                        </div>
                                    </div>
 
                                </div>
 
                                <div class = "form-row">
 
                                    <div class="col-md-1.5 mb-3">
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                            <span class="input-group-text" >Lớp 11</span>
                                            </div>
                                        </div>    
                                    </div>
 
                                    <div class="col-md-2 mb-3">
                                        <div class="input-group">
                                            <input type="text" class="form-control" name= "MaTinh11" required>
                                        </div>
                                    </div>
 
                                    <div class="col-md-3.5 mb-3">
                                        <div class="input-group">
                                            <input type="text" class="form-control" name ="TenTinh11" required>
                                        </div>
                                    </div>
 
                                    <div class="col-md-2 mb-3">
                                        <div class="input-group">
                                            <input type="text" class="form-control" name ="MaTruong11" required>
                                        </div>
                                    </div>
 
                                    <div class="col-md-3 mb-3">
                                        <div class="input-group">
                                                <input type="text" class="form-control" name ="TenTruong11" required>
                                        </div>
                                    </div>
 
                                </div>
 
                                <div class = "form-row">
 
                                    <div class="col-md-1.5 mb-3">
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                            <span class="input-group-text" >Lớp 12</span>
                                            </div>
                                        </div>    
                                    </div>
 
                                    <div class="col-md-2 mb-3">
                                        <div class="input-group">
                                            <input type="text" class="form-control" name ="MaTinh12" required>
                                        </div>
                                    </div>
 
                                    <div class="col-md-3.5 mb-3">
                                        <div class="input-group">
                                            <input type="text" class="form-control" name ="TenTinh12" required>
                                        </div>
                                    </div>
 
                                    <div class="col-md-2 mb-3">
                                        <div class="input-group">
                                            <input type="text" class="form-control" name="MaTruong12" required>
                                        </div>
                                    </div>
 
                                    <div class="col-md-3 mb-3">
                                        <div class="input-group">
                                                <input type="text" class="form-control" name = "TenTruong12" required>
                                        </div>
                                    </div>
 
                                </div>
 
                                <div class="form-row">
                                    <div class="col-md-9">
                                        <lable>Đối tượng ưu tiên tuyển sinh (Thuộc đối tượng nào thì chọn đối tượng bên phải)</lable>
 
                                    </div>
                                    <div class="col-md-2">
                                        <select name="DoiTuongUT" class ="form-control"id="tuyensinh">
                                        <option >kv1</option> 
                                        <option >kv2</option> 
                                        <option >kv3</option> 
                                        <option >kv4</option>     
                                        </select>
                                    </div>  
                                </div> 
                                <br>
                                <div class="form-row">
                                    <div class="col-md-9">
                                        <lable>Khu vực ưu tiên tuyển sinh (Thuộc đối tượng nào thì chọn kí hiệu của khu vực (kv1, kv2..) vào ô khu vực ưu tiên)</lable>
 
                                    </div>
                                    <br>
                                    <div class="col-md-2">
                                        <select name="KhuVucUT" class ="form-control">
                                        <option >kv1</option>   
                                        <option >kv2</option>
                                        <option >kv3</option> 
                                        <option >kv4</option>   
                                        </select>
                                    </div>
                                </div>
                                
                                <br>
                                 <div class = "form-row">
                                    <div class="col-md-12 mb-3">
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text">Địa chỉ liên hệ</span>
                                            </div>
                                            <input type="text" class="form-control"  name = "DiaChiLH" id="validationDefaultUsername" placeholder="Nhập địa chỉ" aria-describedby="inputGroupPrepend2" required>
                                        </div>
                                    </div>
                                </div> 
 
                                <div class = "form-row">
                                    <div class="col-md-6 mb-3">
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text" >Điện thoại thí sinh</span>
                                            </div>
                                            <input type="text" class="form-control" name = "Sdths"  placeholder="Nhập SDT" aria-describedby="inputGroupPrepend2" required>
                                        </div>
                                    </div>
 
                                    <div class=" col-md-6 mb-3">
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text" name = "Sdtph" id="inputGroupPrepend2">Điện thoại phụ huynh</span>
                                            </div>
                                            <input type="text" class="form-control" name = "Sdtph" placeholder="Nhập SDT" aria-describedby="inputGroupPrepend2" required>
                                        </div>
                                    </div>
                                </div>    
                                
                                <br>
                                <br>
                                <br>
 
                                <h3 class ="bg-success text-center" style="font-weight: 700;">THÔNG TIN ĐĂNG KÝ </h3>
                                <br>
                                    <lable>Sau khi đã đọc và hiểu rõ các quy định vể tiêu chí và điều kiện xét tuyển của nhà trường, tôi đồng ý xét tuyển học bạ vào trình độ đại học như sau (Chọn phương thức xét tuyển)</lable>
                                <br>
                                <br>
                                <div lass = "form-group">
                                    <input type="radio"  name="Dtb12" checked = "checked" value = " TB 3môn lớp 12">
                                    <label class = "radio-lable"> Tuyển bằng tổng điểm trung bình lớp 12 theo tổng điểm 3 môn</label>
                                <br>
                                    <input type="radio" name="Dtb12" value ="trung bình (HK1 , HK2 lớp 11  )">
                                    <label for="vehicle2">Tuyển bằng tổng điểm trung bình (HK1, HK2 lớp 11  )</label><br>
                                </div>
                                <button class ="btn btn-primary btn-center" type ="submit" name = 'save' >Lưu lại</button>
                                <button class ="btn btn-primary btn-center" type ="submit" name = 'quaylai' ><a href="webkhoa.php" style="color: white; text-decoration:none;">Quay lại</a> </button>

                            </form>
                        </div>
                 </div>
            </div>
        
        </div>
    </div>
</body>
</html>
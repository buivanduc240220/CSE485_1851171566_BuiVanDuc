<?php
    $conn = mysqli_connect('localhost','root','','cuoiky');
    if(!$conn){
        die('Lỗi! Không thể kết nối');
        exit();
    }
?>